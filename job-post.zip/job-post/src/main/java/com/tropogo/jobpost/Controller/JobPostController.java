package com.tropogo.jobpost.Controller;

import com.tropogo.jobpost.Dto.Account;
import com.tropogo.jobpost.Dto.JobPost;
import com.tropogo.jobpost.Service.JobPostService;
import com.tropogo.jobpost.Service.UserService;
import com.tropogo.jobpost.Util.ConstantUtil;
import com.tropogo.jobpost.Util.DataLayerException;
import com.tropogo.jobpost.Util.UtilityClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class JobPostController {


    private final JobPostService jobPostService;

    private final UserService userService;

    @Autowired
    JobPostController(JobPostService jobPostService,UserService userService)
    {
        this.userService = userService;
        this.jobPostService = jobPostService;
    }

    @GetMapping("/jobposts")
    public List<JobPost> getAllJobPosts()
    {
        return jobPostService.getAll();
    }

    @PostMapping("/users/{userId}/jobposts")
    public String addJobPost(@PathVariable long userId, @RequestBody JobPost jobPost)
    {
        if(!userService.isExist(userId))
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST, ConstantUtil.UserNotExist);
        if(!UtilityClass.isValid(jobPost))
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,ConstantUtil.InvalidMessage);

        jobPost.setUser(new Account(userId,"","",""));
        try {
            jobPostService.addJobPost(jobPost);
        } catch (DataLayerException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,ConstantUtil.Dataunsaved);
        }
        return ConstantUtil.PostCreated;
    }

}
