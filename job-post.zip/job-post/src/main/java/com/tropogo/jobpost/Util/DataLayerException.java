package com.tropogo.jobpost.Util;

import org.springframework.transaction.UnexpectedRollbackException;

public class DataLayerException extends Throwable {
    public DataLayerException(String constraint_violation, UnexpectedRollbackException ex) {
        super(constraint_violation);
    }
}
