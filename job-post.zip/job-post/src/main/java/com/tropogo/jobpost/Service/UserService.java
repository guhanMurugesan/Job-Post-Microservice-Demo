package com.tropogo.jobpost.Service;

import com.tropogo.jobpost.Dto.Account;
import com.tropogo.jobpost.Repository.UserRepository;
import com.tropogo.jobpost.Util.ConstantUtil;
import com.tropogo.jobpost.Util.DataLayerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.UnexpectedRollbackException;

import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;
    public void addUser(Account account) throws DataLayerException {
        try {
            userRepository.save(account);
        }
        catch(UnexpectedRollbackException ex){
            if(ex.getMostSpecificCause() instanceof SQLIntegrityConstraintViolationException){
                throw new DataLayerException(ConstantUtil.ConstraintViolation, ex);
            }
        }
    }
    public List<Account> getAll()
    {
        List<Account> accounts = new ArrayList<>();
        userRepository.findAll().forEach(accounts::add);
        return accounts;
    }

    public boolean isExist(long userId) {
        return userRepository.findById(userId) != null;
    }


}
