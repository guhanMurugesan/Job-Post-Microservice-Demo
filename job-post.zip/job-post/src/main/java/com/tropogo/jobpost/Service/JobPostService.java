package com.tropogo.jobpost.Service;

import com.tropogo.jobpost.Dto.JobPost;
import com.tropogo.jobpost.Repository.JobPostRepository;
import com.tropogo.jobpost.Util.ConstantUtil;
import com.tropogo.jobpost.Util.DataLayerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.UnexpectedRollbackException;

import java.lang.invoke.ConstantCallSite;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

@Service
public class JobPostService {

    private final JobPostRepository jobPostRepository;

    @Autowired
    public JobPostService(JobPostRepository jobPostRepository) {
        this.jobPostRepository = jobPostRepository;
    }

    public List<JobPost> getAll()
    {
        List<JobPost> posts = new ArrayList();
        for(JobPost jp : jobPostRepository.findAll())
            posts.add(jp);
        return posts;
    }

    public void addJobPost(JobPost jobPost) throws DataLayerException
    {
        try{
            jobPostRepository.save(jobPost);
        }
        catch(UnexpectedRollbackException ex){
            if(ex.getMostSpecificCause() instanceof SQLIntegrityConstraintViolationException){
                throw new DataLayerException(ConstantUtil.ConstraintViolation, ex);
            }
        }

    }


}
