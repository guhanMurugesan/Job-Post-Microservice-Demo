package com.tropogo.jobpost.Repository;

import com.tropogo.jobpost.Dto.Account;
import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<Account,Long> {
    Account findById(long userId);
}
