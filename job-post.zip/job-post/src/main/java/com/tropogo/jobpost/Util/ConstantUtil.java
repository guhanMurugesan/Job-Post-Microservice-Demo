package com.tropogo.jobpost.Util;

public class ConstantUtil {
    public static final String UserCreated = "User is created";
    public static final String PostCreated = "Job post is created";
    public static final String UserNotExist = "User not Exists";
    public static final String InvalidMessage = "Invalid data";
    public  static final String Dataunsaved = "Data not saved";
    public static final String ConstraintViolation = "constraint violation";
}
