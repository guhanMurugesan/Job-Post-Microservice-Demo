package com.tropogo.jobpost.Controller;

import com.tropogo.jobpost.Dto.Account;
import com.tropogo.jobpost.Util.ConstantUtil;
import com.tropogo.jobpost.Util.DataLayerException;
import com.tropogo.jobpost.Service.UserService;
import com.tropogo.jobpost.Util.UtilityClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService)
    {
        this.userService = userService;
    }

    @PostMapping("/users")
    public String addUser(@RequestBody Account account)
    {
        if(!UtilityClass.isValid(account)) {
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST, ConstantUtil.InvalidMessage);
        }
        try {
            userService.addUser(account);
        } catch (DataLayerException e) {
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,ConstantUtil.Dataunsaved);
        }
        return ConstantUtil.UserCreated;
    }

    @GetMapping("/users")
    public List<Account> getUser()
    {
        return userService.getAll();
    }

}
