package com.tropogo.jobpost.Repository;

import com.tropogo.jobpost.Dto.JobPost;
import org.springframework.data.repository.CrudRepository;

public interface JobPostRepository extends CrudRepository<JobPost,Long> {
}
